using System;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class Page_MQPE3000 : PX.Web.UI.PXPage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        this.Master.PopupHeight = 720;
        this.Master.PopupWidth = 975;
    }
}
